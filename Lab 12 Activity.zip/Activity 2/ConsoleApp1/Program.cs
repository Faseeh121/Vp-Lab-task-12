﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[7] { 1, 2, 3, 4, 5, 6, 7 };
            var numquery = from num in numbers
                           where (num % 2 == 0)
                           select num;



            foreach (int num in numquery)
            {
                Console.WriteLine(num);

            }


            StudentClass c = new StudentClass();
            c.QueryHighScores(1, 90);

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();

        }
    }


    public class StudentClass
    {
        public enum Gradelevel { firstyear = 1, secondyear, thirdyear };

        protected class Student
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int ID { get; set; }

            public Gradelevel Year;
            public List<int> ExamScores;

        }


        protected static List<Student> students = new List<Student>
        {
            new Student { FirstName = "Terry ", LastName = "Adams", ID = 120, Year = Gradelevel.secondyear,
                ExamScores = new List<int> { 99, 82, 81, 71 }
            },
            new Student { FirstName = "Fadi ", LastName = "Fakhouri", ID = 116, Year = Gradelevel.thirdyear,
                ExamScores = new List<int> { 99, 86, 90, 79 }
            },
             new Student { FirstName = "Wasay ", LastName = "Siyal", ID = 130, Year = Gradelevel.thirdyear,
                ExamScores = new List<int> { 99, 86, 90, 99 }
            },
              new Student { FirstName = "Mahateer ", LastName = "Passo", ID = 135, Year = Gradelevel.firstyear,
                ExamScores = new List<int> { 99, 76, 70, 69 }
            },
               new Student { FirstName = "Mahad ", LastName = "Ghauri", ID = 140, Year = Gradelevel.secondyear,
                ExamScores = new List<int> { 91, 92, 88, 59 }
            },
                new Student { FirstName = "Hassan ", LastName = "Raza", ID = 145, Year = Gradelevel.secondyear,
                ExamScores = new List<int> { 91, 92, 85, 94 }
            },
        };

        protected static int GetPercentile(Student s)
        {
            double avg = s.ExamScores.Average();
            return avg > 0 ? (int)avg / 10 : 0;
        }

        public void QueryHighScores(int exam, int score)
        {
            var highscores = from student in students
                             where student.ExamScores[exam] > score
                             select new { Name = student.FirstName, Score = student.ExamScores[exam] };
            foreach (var item in highscores)
            {
                Console.WriteLine("{0, -10}{1}", item.Name, item.Score);
            }


        }








    }

}
